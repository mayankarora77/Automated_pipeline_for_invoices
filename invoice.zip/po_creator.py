from sqlalchemy import select

from database import SessionLocal
from models import PurchaseOrder, PurchaseOrderItem


def save_purchase_order(invoice_data):
    """
    Save extracted invoice details as a purchase order
    and save its items in the purchase_order_items table.
    """

    po_number = invoice_data.purchase_order_number

    if not po_number:
        raise ValueError(
            "Purchase order number was not found in the invoice."
        )

    db = SessionLocal()

    try:
        # Check whether this PO already exists
        existing_po = db.scalars(
            select(PurchaseOrder).where(
                PurchaseOrder.po_number == po_number
            )
        ).first()

        if existing_po:
            raise ValueError(
                f"Purchase order {po_number} already exists."
            )

        # Create the purchase order record
        purchase_order = PurchaseOrder(
            po_number=po_number,
            vendor_name=invoice_data.vendor_name,
            total_amount=invoice_data.total_amount or 0,
            status="open",
        )

        db.add(purchase_order)

        # Flush sends the INSERT to PostgreSQL and gives us the new ID
        db.flush()

        # Create item records connected to this PO
        for invoice_item in invoice_data.items or []:
            purchase_order_item = PurchaseOrderItem(
                purchase_order_id=purchase_order.id,
                description=invoice_item.description,
                quantity=invoice_item.quantity or 0,
                unit_price=invoice_item.price or 0,
            )

            db.add(purchase_order_item)

        # Save everything permanently
        db.commit()

        return {
            "message": "Purchase order saved successfully.",
            "purchase_order_id": purchase_order.id,
            "po_number": purchase_order.po_number,
            "vendor_name": purchase_order.vendor_name,
            "total_amount": float(purchase_order.total_amount),
            "items_saved": len(invoice_data.items or []),
        }

    except Exception:
        db.rollback()
        raise

    finally:
        db.close()