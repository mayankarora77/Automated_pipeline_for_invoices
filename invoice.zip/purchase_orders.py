from schemas import PurchaseOrder


PURCHASE_ORDERS = {
    "PO-1001": PurchaseOrder(
        po_number="PO-1001",
        vendor_name="ABC Suppliers",
        items=[
            {
                "description": "Laptop",
                "quantity": 5,
                "unit_price": 50000,
            },
            {
                "description": "Mouse",
                "quantity": 5,
                "unit_price": 1000,
            },
        ],
        total_amount=255000,
    )
}