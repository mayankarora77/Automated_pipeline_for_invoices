from pathlib import Path
from tempfile import NamedTemporaryFile

from fastapi import FastAPI, UploadFile, File, HTTPException

from ocr import extract_text
from llm_extracter import extract_invoice_data
from po_creator import save_purchase_order

from po_matcher import (
    find_purchase_order,
    find_purchase_order_by_details,
    compare_invoice_with_purchase_order,
)


app = FastAPI()


MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

SUPPORTED_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
}

SUPPORTED_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
}


@app.get("/")
async def home():
    return {
        "message": "Invoice Auditor API is running"
    }


@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):

    # 1. Validate file extension
    extension = Path(file.filename or "").suffix.lower()

    if extension not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file extension"
        )

    # 2. Validate MIME type
    if file.content_type not in SUPPORTED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Unsupported image format"
        )

    # 3. Read uploaded file
    contents = await file.read()

    # 4. Validate file size
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail="File is too large. Maximum allowed size is 10 MB."
        )

    # 5. Save uploaded image temporarily
    with NamedTemporaryFile(
        delete=False,
        suffix=extension
    ) as temporary_file:
        temporary_file.write(contents)
        temporary_file_path = temporary_file.name

    try:
        # 6. Extract text using OCR
        ocr_text = extract_text(temporary_file_path)

        # 7. Extract structured invoice data using Groq
        invoice_data = extract_invoice_data(ocr_text)

        # 8. First try matching by PO number
        purchase_order = find_purchase_order(
            invoice_data.purchase_order_number
        )

        # 9. If PO number is missing, match by vendor name
        if purchase_order is None:
            purchase_order = find_purchase_order_by_details(
                vendor_name=invoice_data.vendor_name,
            )

        # 10. Compare invoice with the matched purchase order
        comparison = compare_invoice_with_purchase_order(
            invoice_data=invoice_data,
            purchase_order=purchase_order,
        )

        # 11. Return the complete result
        return {
            "filename": file.filename,
            "content_type": file.content_type,
            "ocr_text": ocr_text,
            "invoice_data": invoice_data.model_dump(),
            "purchase_order": purchase_order,
            "comparison": comparison,
        }

    finally:
        # 12. Delete temporary image
        Path(temporary_file_path).unlink(missing_ok=True)


@app.post("/add-purchase-order")
async def add_purchase_order(file: UploadFile = File(...)):

    # 1. Validate file extension
    extension = Path(file.filename or "").suffix.lower()

    if extension not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file extension"
        )

    # 2. Validate MIME type
    if file.content_type not in SUPPORTED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Unsupported image format"
        )

    # 3. Read uploaded file
    contents = await file.read()

    # 4. Validate file size
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail="File is too large. Maximum allowed size is 10 MB."
        )

    # 5. Save uploaded image temporarily
    with NamedTemporaryFile(
        delete=False,
        suffix=extension
    ) as temporary_file:
        temporary_file.write(contents)
        temporary_file_path = temporary_file.name

    try:
        # 6. Extract text using OCR
        ocr_text = extract_text(temporary_file_path)

        # 7. Extract structured invoice data using Groq
        invoice_data = extract_invoice_data(ocr_text)

        # 8. Save extracted invoice data as a purchase order
        database_result = save_purchase_order(invoice_data)

        # 9. Return the saved result
        return {
            "filename": file.filename,
            "content_type": file.content_type,
            "ocr_text": ocr_text,
            "invoice_data": invoice_data.model_dump(),
            "database_result": database_result,
        }

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Could not save purchase order: {str(error)}"
        )

    finally:
        # 10. Delete temporary image
        Path(temporary_file_path).unlink(missing_ok=True)