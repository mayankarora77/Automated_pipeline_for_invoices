from pathlib import Path

from PIL import Image
import pytesseract


# Tesseract executable location on Windows
pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)


def extract_text(image_path: str) -> str:
    image = Image.open(image_path)

    try:
        extracted_text = pytesseract.image_to_string(image)
    finally:
        image.close()

    return extracted_text


if __name__ == "__main__":
    invoice_path = "invoice.jpeg"

    if not Path(invoice_path).exists():
        print(f"File not found: {invoice_path}")
    else:
        extracted_text = extract_text(invoice_path)

        print("\n----- EXTRACTED INVOICE TEXT -----\n")
        print(extracted_text)