from sqlalchemy import select

from database import SessionLocal
from models import PurchaseOrder


def find_purchase_order(po_number: str):
    """
    Find a purchase order using its PO number.
    """

    if not po_number:
        return None

    db = SessionLocal()

    try:
        statement = (
            select(PurchaseOrder)
            .where(PurchaseOrder.po_number == po_number)
        )

        purchase_order = db.scalars(statement).first()

        if purchase_order is None:
            return None

        return convert_purchase_order_to_dict(purchase_order)

    finally:
        db.close()


def find_purchase_order_by_details(
    vendor_name: str = None,
    total_amount: float = None,
):
    """
    Find a purchase order using vendor name and total amount.
    """

    if not vendor_name and total_amount is None:
        return None

    db = SessionLocal()

    try:
        statement = select(PurchaseOrder)

        if vendor_name:
            statement = statement.where(
                PurchaseOrder.vendor_name.ilike(vendor_name)
            )

        if total_amount is not None:
            statement = statement.where(
                PurchaseOrder.total_amount == total_amount
            )

        purchase_order = db.scalars(statement).first()

        if purchase_order is None:
            return None

        return convert_purchase_order_to_dict(purchase_order)

    finally:
        db.close()


def convert_purchase_order_to_dict(purchase_order):
    """
    Convert a SQLAlchemy purchase-order object
    into a normal Python dictionary.
    """

    return {
        "id": purchase_order.id,
        "po_number": purchase_order.po_number,
        "vendor_name": purchase_order.vendor_name,
        "total_amount": float(purchase_order.total_amount),
        "status": purchase_order.status,
        "items": [
            {
                "description": item.description,
                "quantity": float(item.quantity),
                "unit_price": float(item.unit_price),
            }
            for item in purchase_order.items
        ],
    }


def compare_invoice_with_purchase_order(
    invoice_data,
    purchase_order,
):
    """
    Compare extracted invoice data with a matched purchase order.
    """

    if purchase_order is None:
        return {
            "status": "not_matched",
            "message": "No matching purchase order was found.",
            "differences": [],
        }

    differences = []

    # Compare vendor names
    invoice_vendor = (invoice_data.vendor_name or "").strip().lower()
    po_vendor = (purchase_order["vendor_name"] or "").strip().lower()

    if invoice_vendor != po_vendor:
        differences.append({
            "field": "vendor_name",
            "invoice_value": invoice_data.vendor_name,
            "purchase_order_value": purchase_order["vendor_name"],
            "message": "Vendor names do not match.",
        })

    # Compare total amounts
    invoice_total = invoice_data.total_amount
    po_total = purchase_order["total_amount"]

    if invoice_total is not None:
        if abs(float(invoice_total) - float(po_total)) > 0.01:
            differences.append({
                "field": "total_amount",
                "invoice_value": float(invoice_total),
                "purchase_order_value": float(po_total),
                "message": "Invoice total does not match purchase-order total.",
            })

    # Compare item counts
    invoice_items = invoice_data.items or []
    po_items = purchase_order["items"]

    if len(invoice_items) != len(po_items):
        differences.append({
            "field": "item_count",
            "invoice_value": len(invoice_items),
            "purchase_order_value": len(po_items),
            "message": "The number of invoice items does not match the number of purchase-order items.",
        })

    # Compare items by position for now
    comparison_count = min(
        len(invoice_items),
        len(po_items),
    )

    for index in range(comparison_count):
        invoice_item = invoice_items[index]
        po_item = po_items[index]

        invoice_description = (
            invoice_item.description or ""
        ).strip().lower()

        po_description = (
            po_item["description"] or ""
        ).strip().lower()

        if invoice_description != po_description:
            differences.append({
                "field": f"items[{index}].description",
                "invoice_value": invoice_item.description,
                "purchase_order_value": po_item["description"],
                "message": "Item descriptions do not match.",
            })

        if invoice_item.quantity is not None:
            if abs(
                float(invoice_item.quantity)
                - float(po_item["quantity"])
            ) > 0.01:
                differences.append({
                    "field": f"items[{index}].quantity",
                    "invoice_value": float(invoice_item.quantity),
                    "purchase_order_value": float(po_item["quantity"]),
                    "message": "Item quantities do not match.",
                })

        if invoice_item.price is not None:
            if abs(
                float(invoice_item.price)
                - float(po_item["unit_price"])
            ) > 0.01:
                differences.append({
                    "field": f"items[{index}].price",
                    "invoice_value": float(invoice_item.price),
                    "purchase_order_value": float(po_item["unit_price"]),
                    "message": "Item prices do not match.",
                })

    if differences:
        status = "mismatched"
    else:
        status = "matched"

    return {
        "status": status,
        "message": (
            "Invoice matches the purchase order."
            if status == "matched"
            else "Invoice contains differences from the purchase order."
        ),
        "differences": differences,
    }