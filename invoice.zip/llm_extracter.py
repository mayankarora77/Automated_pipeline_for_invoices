import json
import os

from dotenv import load_dotenv
from openai import OpenAI

from schemas import InvoiceData


load_dotenv()


groq = OpenAI(
    api_key=os.getenv("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1",
)

MODEL = "openai/gpt-oss-120b"


def extract_invoice_data(ocr_text: str) -> InvoiceData:
    response = groq.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": (
                    "Extract invoice information from OCR text and return "
                    "only valid JSON. Do not guess missing values. "
                    "Use null when information is missing. "
                    "Use numbers for quantity, price, tax, amount, "
                    "and total_amount. "
                    "The purchase order number may be missing."
                ),
            },
            {
                "role": "user",
                "content": f"""
Convert this OCR invoice text into JSON.

Required structure:

{{
    "invoice_number": null,
    "invoice_date": null,
    "due_date": null,
    "vendor_name": null,
    "purchase_order_number": null,
    "items": [],
    "total_amount": null
}}

Each item should contain:

{{
    "description": null,
    "quantity": null,
    "price": null,
    "tax": null,
    "amount": null
}}

Rules:

- Return null when a value is not visible.
- Do not invent a purchase order number.
- Keep invoice numbers as strings.
- Keep dates as strings.
- Convert monetary values to numbers when possible.
- Do not include explanations outside the JSON.

OCR text:

{ocr_text}
""",
            },
        ],
        response_format={"type": "json_object"},
    )

    raw_json = response.choices[0].message.content

    if not raw_json:
        raise ValueError("Groq returned an empty response.")

    parsed_json = json.loads(raw_json)

    return InvoiceData.model_validate(parsed_json)